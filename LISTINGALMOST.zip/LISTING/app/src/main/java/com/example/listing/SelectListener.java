package com.example.listing;

public interface SelectListener {
    void onItemClicked(Item item);
}
